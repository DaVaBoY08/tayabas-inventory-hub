import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { directus, directusService } from "@/lib/directus";
import { toast } from "sonner";
import { Custodian } from "@/types";
import { useAuth } from "./useAuth";

export function useCustodians() {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: custodians = [], isLoading } = useQuery({
    queryKey: ['custodians'],
    queryFn: async () => {
      try {
        const response = await directusService.getItems<Custodian>('custodians');
        return response.data.map(custodian => ({ ...custodian, id: String(custodian.id) }));
      } catch (error) {
        console.error('Failed to fetch custodians:', error);
        toast.error('Failed to load custodians');
        return [];
      }
    },
    enabled: !!user,
  });

  const createMutation = useMutation({
    mutationFn: (newCustodian: Partial<Custodian>) =>
      directus.createItem<Custodian>('custodians', newCustodian),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custodians'] });
      toast.success('Custodian added successfully');
    },
    onError: () => {
      toast.error('Failed to add custodian');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Custodian> }) =>
      directus.updateItem<Custodian>('custodians', id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custodians'] });
      toast.success('Custodian updated successfully');
    },
    onError: () => {
      toast.error('Failed to update custodian');
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => directus.deleteItem('custodians', id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['custodians'] });
      toast.success('Custodian deleted successfully');
    },
    onError: () => {
      toast.error('Failed to delete custodian');
    },
  });

  return {
    custodians,
    isLoading,
    createCustodian: createMutation.mutate,
    updateCustodian: updateMutation.mutate,
    deleteCustodian: deleteMutation.mutate,
  };
}
